create function estiminate_cff(elem character varying) returns integer
    language plpgsql
as
$$
BEGIN
    if (elem= 'A') then return 20;
    elseif(elem = 'B') then return 10;
    elseif(elem = 'C') then return 0;
    elseif(elem = 'D') then return -10;
    elseif(elem = 'E') then return -20;
    end if;
END;
$$;

alter function estiminate_cff(varchar) owner to postgres;

