create function count_employee_rolling_change() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE department
    SET number_employees = src.cnt
    FROM (SELECT department_id, count(1) as cnt FROM employees group by department_id) src
    WHERE src.department_id = department.id;
    RETURN NEW;
END;
$$;

alter function count_employee_rolling_change() owner to postgres;

